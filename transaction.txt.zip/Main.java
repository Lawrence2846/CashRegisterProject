import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

class User {
    String username;
    String password;

    User(String username, String password) {
        this.username = username;
        this.password = password;
    }
}

class TransactionLogger {
    public static void logTransaction(String username, List<String> items, double total) {
        try (FileWriter writer = new FileWriter("transactions.txt", true)) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String timestamp = LocalDateTime.now().format(formatter);
            writer.write("Date/Time: " + timestamp + "\n");
            writer.write("Cashier: " + username + "\n");
            writer.write("Items:\n");
            for (String item : items) {
                writer.write(" - " + item + "\n");
            }
            writer.write("Total: " + total + "\n");
            writer.write("========================================\n");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> productNames = new ArrayList<>();
        ArrayList<Double> productPrices = new ArrayList<>();
        ArrayList<Integer> productQuantities = new ArrayList<>();
        ArrayList<User> users = new ArrayList<>();
        User currentUser = null;

        productNames.add("Helmet");
        productPrices.add(1500.0);
        productQuantities.add(10);

        productNames.add("Handlebar");
        productPrices.add(800.0);
        productQuantities.add(8);

        productNames.add("Brakes");
        productPrices.add(1200.0);
        productQuantities.add(5);

        productNames.add("Tire");
        productPrices.add(1000.0);
        productQuantities.add(12);

        productNames.add("Headlight");
        productPrices.add(500.0);
        productQuantities.add(15);

        // Regex patterns for username and password
        Pattern usernamePattern = Pattern.compile("^[a-zA-Z0-9]{5,15}$");
        Pattern passwordPattern = Pattern.compile("^(?=.*[A-Z])(?=.*\\d).{8,20}$");

        while (currentUser == null) {
            System.out.println("1. Sign Up");
            System.out.println("2. Login");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 1) {
                System.out.print("Enter username: ");
                String uname = scanner.nextLine();
                System.out.print("Enter password: ");
                String pass = scanner.nextLine();

                Matcher unameMatcher = usernamePattern.matcher(uname);
                Matcher passMatcher = passwordPattern.matcher(pass);

                if (!unameMatcher.matches()) {
                    System.out.println("Invalid username. It must be 5-15 characters long and contain only letters and digits.");
                    continue;
                }

                if (!passMatcher.matches()) {
                    System.out.println("Invalid password. It must be 8-20 characters long, contain at least one uppercase letter and one digit.");
                    continue;
                }

                users.add(new User(uname, pass));
                System.out.println("Sign-up successful!");
            } else if (choice == 2) {
                System.out.print("Enter username: ");
                String uname = scanner.nextLine();
                System.out.print("Enter password: ");
                String pass = scanner.nextLine();

                for (User u : users) {
                    if (u.username.equals(uname) && u.password.equals(pass)) {
                        currentUser = u;
                        break;
                    }
                }
                if (currentUser == null) {
                    System.out.println("Invalid credentials. Try again.");
                } else {
                    System.out.println("Login successful. Welcome, " + currentUser.username);
                }
            } else {
                System.out.println("Invalid choice.");
            }
        }

        boolean exit = false;
        while (!exit) {
            System.out.println("\n============================");
            System.out.println("    MOTORCYCLE PARTS STORE    ");
            System.out.println("============================");
            System.out.println("1. Cashier Mode");
            System.out.println("2. Admin Mode");
            System.out.println("3. Exit");
            System.out.print("Enter choice: ");

            int mode = scanner.nextInt();
            scanner.nextLine();

            if (mode == 1) {
                cashierMode(scanner, productNames, productPrices, productQuantities, currentUser);
            } else if (mode == 2) {
                adminMode(scanner, productNames, productPrices, productQuantities);
            } else if (mode == 3) {
                exit = true;
                System.out.println("Exiting system. Thank you!");
            } else {
                System.out.println("Invalid option. Try again.");
            }
        }
        scanner.close();
    }

    public static void cashierMode(Scanner scanner, ArrayList<String> productNames, ArrayList<Double> productPrices,
                                   ArrayList<Integer> productQuantities, User user) {
        double total = 0;
        List<String> purchasedItems = new ArrayList<>();
        boolean addMore = true;

        do {
            try {
                System.out.println("\n============================");
                System.out.println("     AVAILABLE PRODUCTS     ");
                System.out.println("============================");
                for (int i = 0; i < productNames.size(); i++) {
                    System.out.println((i + 1) + ". " + productNames.get(i) + " | Price: " + productPrices.get(i) + " | Stock: " + productQuantities.get(i));
                }

                System.out.print("\nEnter product number to purchase: ");
                int index = scanner.nextInt() - 1;
                if (index < 0 || index >= productNames.size()) {
                    System.out.println("Invalid product number.");
                    continue;
                }

                System.out.print("Enter quantity: ");
                int quantity = scanner.nextInt();
                if (quantity <= productQuantities.get(index)) {
                    double subtotal = quantity * productPrices.get(index);
                    total += subtotal;
                    productQuantities.set(index, productQuantities.get(index) - quantity);
                    purchasedItems.add(productNames.get(index) + " x" + quantity + " @ " + productPrices.get(index));
                    System.out.println("Added to cart. Subtotal: " + subtotal);
                } else {
                    System.out.println("Insufficient stock.");
                }

                System.out.print("Add more items? (yes/no): ");
                addMore = scanner.next().equalsIgnoreCase("yes");
            } catch (Exception e) {
                System.out.println("Invalid input. Try again.");
                scanner.nextLine();
                addMore = true;
            }
        } while (addMore);

        processPayment(scanner, total);
        TransactionLogger.logTransaction(user.username, purchasedItems, total);
    }

    public static void processPayment(Scanner scanner, double total) {
        double payment;
        do {
            System.out.print("\nEnter payment amount: ");
            payment = scanner.nextDouble();
            if (payment < total) {
                System.out.println("Insufficient amount! Please enter a valid payment.");
            }
        } while (payment < total);
        System.out.println("Change: " + (payment - total));
    }

    public static void adminMode(Scanner scanner, ArrayList<String> productNames, ArrayList<Double> productPrices, ArrayList<Integer> productQuantities) {
        boolean adminExit = false;

        while (!adminExit) {
            System.out.println("\n============================");
            System.out.println("       ADMIN OPTIONS       ");
            System.out.println("============================");
            System.out.println("1. View Products");
            System.out.println("2. Add Product");
            System.out.println("3. Remove Product");
            System.out.println("4. Exit Admin Mode");
            System.out.print("Enter choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 1) {
                viewProducts(productNames, productPrices, productQuantities);
            } else if (choice == 2) {
                addProduct(scanner, productNames, productPrices, productQuantities);
            } else if (choice == 3) {
                removeProduct(scanner, productNames, productPrices, productQuantities);
            } else if (choice == 4) {
                adminExit = true;
                System.out.println("Exiting Admin Mode...");
            } else {
                System.out.println("Invalid choice. Try again.");
            }
        }
    }

    public static void viewProducts(ArrayList<String> productNames, ArrayList<Double> productPrices, ArrayList<Integer> productQuantities) {
        System.out.println("\n============================");
        System.out.println("       PRODUCT LIST       ");
        System.out.println("============================");
        for (int i = 0; i < productNames.size(); i++) {
            System.out.println((i + 1) + ". " + productNames.get(i) + " | Price: " + productPrices.get(i) + " | Stock: " + productQuantities.get(i));
        }
    }

    public static void addProduct(Scanner scanner, ArrayList<String> productNames, ArrayList<Double> productPrices, ArrayList<Integer> productQuantities) {
        System.out.print("\nEnter product name: ");
        String name = scanner.nextLine();
        System.out.print("Enter price: ");
        double price = scanner.nextDouble();
        System.out.print("Enter quantity: ");
        int quantity = scanner.nextInt();

        productNames.add(name);
        productPrices.add(price);
        productQuantities.add(quantity);
        System.out.println("Product added successfully.");
    }

    public static void removeProduct(Scanner scanner, ArrayList<String> productNames, ArrayList<Double> productPrices, ArrayList<Integer> productQuantities) {
        System.out.print("Enter product number to remove: ");
        int index = scanner.nextInt() - 1;
        if (index >= 0 && index < productNames.size()) {
            productNames.remove(index);
            productPrices.remove(index);
            productQuantities.remove(index);
            System.out.println("Product removed successfully.");
        } else {
            System.out.println("Invalid product number.");
        }
    }
}

